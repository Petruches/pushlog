import asyncio
import keyboard
import webbrowser
import sys

def mat(value) -> float:
    return eval(value)

async def shutdown():
    while True:
        if (keyboard.wait("esc")):
            await print("Типа выход")
            #exit()

def culc():
    res = str(input("Введите выражение: "))
    try:
        try:
            print(mat(res))
            print()
            main()
        except ZeroDivisionError as ze:
            print("На ноль делить нельзя\nПовторите снова!")
            culc()
    except Exception as e:
        print("Нельзя такое вводить!!!\nПопробуйте ещё раз\n")
        culc()

def main():
    #await shutdown()
    print("Калькулятор")
    print("Выберите 1 если хотите использовать калькулятор\nВыберите 2 если хотите выйти")
    try:
        inp = str(input())
    except KeyboardInterrupt as e:
        print("F")
        sys.exit(1)
    
    if (inp == "1"):
        culc()
    elif (inp == "2"):
        exit()
    else:
        webbrowser.open('https://www.youtube.com/watch?v=GMETU0BZc7k', new=2)
        main()

if __name__ == "__main__":
	#asyncio.run(main())
    main()
