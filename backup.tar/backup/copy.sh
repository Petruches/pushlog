#!/bin/bash

i=0
#NML=$(find /Users/p.bykov/dir1 -name "log.log" | cut -c27-33)
#set -- $NML

for lll in $(/usr/bin/find /Users/p.bykov/dir1 -name "log.log")
do
    #NML=$(/usr/bin/find /Users/p.bykov/dir1 -name "log.log" | cut -c27-33)
    #DT=$(/usr/bin/find /Users/p.bykov/dir1 -name "log.log" | cut -c21-25 | tr '/' '_')



    #((i=i+1))

    NAME=$lll
    echo $NAME

    #echo $lll
    #/bin/cp $lll /Users/p.bykov/dir2/dircopy/
done
#/bin/ls -la /Users/p.bykov/dir2/dircopy/

exit 0
