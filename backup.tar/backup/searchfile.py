import os

files_dir = os.listdir('/Users/p.bykov/dir1')
print(files_dir)

only_files = []
for fd in files_dir:
    if os.path.isdir('/Users/p.bykov/dir1/'+fd):
        only_files.append(fd)
    print('/Users/p.bykov/dir1/'+fd)



#for of in only_files:
#    print('/Users/p.bykov/dir1/'+of)

#print('-'*30)

#for of in only_files:
#    os.rename('/Users/p.bykov/dir1/'+of, '/Users/p.bykov/dir2/'+of)
#    print('/Users/p.bykov/dir2/'+of)
