openfile = open("/Users/p.bykov/myscripts/testfile", "r")

#while True:
#    chunk = openfile.readline()
#    print(chunk)

chunk = openfile.readline()
#print(chunk)

a=0
for line in openfile:
    print(line)
    a+=1
    if a == 4:
        break

print(a+1)
