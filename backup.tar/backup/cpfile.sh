#!/bin/bash

file="find /Users/p.bykov/dir1 -name log.log"
file="find ./dir1 -name log.log"
cd /Users/p.bykov/dir1
find . -name log.log

for f in $file
do
#$file | tr '/' '_'

done
