import random

def attack():
        dmg = ["Вы сбежали", "Не убежали"]
        rnd = random.choices(dmg, weights = [1, 5])
        print(rnd)

attack()
