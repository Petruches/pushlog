#!/bin/bash


FILE=$(find /remotelogs/unix-log-m1-01/2023/relk-production/2023/01/ -name "k8s-qw.log.bz2" | sort)
#FILE=/remotelogs/unix-log-dl-01/v2/storage/RELK/relk-production/2022/01/01/k8s-qw.log.bz2

for FL in $FILE
do
bzgrep "Getting credit agreement PDF" $FL | xargs -I{} --max-procs=4 --max-args=1 -0 echo "{}" \; | /bin/sed -n 's/.*timestamp":"\(.\{19\}\).*contractUid=\(.\{36\}\).*/\1,\2/p' >> /remotelogs/logi/m1/logm1_01.part
done
#/bin/bzcat $FILE | xargs --max-procs=1 --max-args=1 /bin/sed -n 's/.*timestamp":"\(.\{19\}\).*contractUid=\(.\{36\}\).*/\1,\2/p' -I {} \; >> /remotelogs/logi/dl/logdl_01_01.part


#bzgrep "Getting credit agreement PDF" /remotelogs/unix-log-dl-01/v2/storage/RELK/relk-production/2022/09/15/k8s-qw.log.bz2
#| xargs -I{} --max-procs=1 --max-args=1 -0 echo "{}" \; | /bin/sed -n 's/.*timestamp":"\(.\{19\}\).*contractUid=\(.\{36\}\).*/\1,\2/p' >> /remotelogs/logi/dl/logdl_09_15.part