#from pathlib import Path
import glob
import os
import shutil
import sys

#paths = sorted(Path('/Users/p.bykov/dir1/').rglob('*.log'))

#ls = list(map(str, paths))
#print(str(ls))

#os.system("find /Users/p.bykov/dir1/ -name '*.log' | grep log.log")

'''
ls = glob.glob("/Users/p.bykov/dir1/*/*/", recursive=True)

print(ls)
for ls1 in sorted(glob.glob("/Users/p.bykov/dir1/*/*/", recursive=True)):
    print(ls1[-7:])
print("#####################################################\n")



lsd = glob.glob("/Users/p.bykov/dir1/*/*/", recursive=True)


print(ls[0])
print(len(ls))
print("###################################################\n")
'''
sys.stdout = open("/Users/p.bykov/dir1/log.log", 'w')

ls = glob.glob("/Users/p.bykov/dir1/*/*/*.log", recursive=True)
i = 0
while i<len(ls):
    print("-----path/name-----")
    lsecho = ls[i]
    print(lsecho)
    print("-----name-----")
    name = lsecho[-7:]
    print(name)
    print("-----path-----")
    print(lsecho[:26])
    print("-----date-----")
    lsdate = lsecho[-13:-8]
    changelsdate = lsdate.replace('/', '_')
    
    if os.path.exists("/Users/p.bykov/dir2/dircopy") == False:
        os.mkdir("/Users/p.bykov/dir2/dircopy")
    try:
        shutil.copy(ls[i], f"/Users/p.bykov/dir0/{changelsdate}_{name}")
        os.system("/bin/cp /Users/p.bykov/dir0/* /Users/p.bykov/dir2/dircopy/")
        os.system("/bin/rm /Users/p.bykov/dir0/*")
    except Exception as ex:
        print(f"ERROR: {ex}")
    

    i += 1
sys.stdout.close()
