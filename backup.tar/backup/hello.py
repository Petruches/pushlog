import os
import re

directory = "/Users/p.bykov/repositories/dns/zones/"
dir_in = "/Users/p.bykov/repositories/dns/zones/in/"
PATTERN_FILES = r"^[0-9.]*.in-addr.arpa$"
files = os.listdir(directory)
files_in = os.listdir(dir_in)
lst: list = []

rrr = [ files[i] for i in range(len(files)) if os.path.isfile(files[i]) ]

#for i in range(len(files)):
#    if os.path.isdir(f"{directory}/{files[i]}"):
#        print(files[i])

for i in range(len(files_in)):
    if os.path.isfile(f"{dir_in}/{files_in[i]}") and re.search(PATTERN_FILES, files_in[i]):
        lst.append(files_in[i])
        print(files_in[i])
        
print(lst)

#print(files_in)

#if os.path.isfile(rrr):
#    print(files)
