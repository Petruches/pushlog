#!/usr/bin/env python3

with open('/Users/p.bykov/myscripts/python/test.txt', 'a') as file1, open('/Users/p.bykov/myscripts/python/test.txt') as r:
    print(r.readline()[:])
    s = "145.35.250.10.in-addr.arpa."
    file1.write(s.ljust(54) + '\n')
    #for line in r:
    #    file1.write('+' + line[10:])

count = int(input("Введите количество ip: "))

for i in range(count):
    ip=input("Введите ip:\n").split('.')
    ip.reverse()
    record = '.'.join(ip) + ".in-addr.arpa."
    recordpr = "PTR: " + '.'.join(ip) + ".in-addr.arpa."
    file = open('/Users/p.bykov/repositories/dns/zones/in/10.in-addr.arpa', 'a')
    print(record)
    file.write(record.ljust(54) + "3600   IN  PTR    " + '\n')
    file.close()
