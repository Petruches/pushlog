#!/bin/bash

i=0
NM=$(/usr/bin/find /Users/p.bykov/dir1 -name "log.log")
DT=$(/usr/bin/find /Users/p.bykov/dir1 -name "log.log" | cut -c21-25 | tr '/' '_')

for PATH in "$(/usr/bin/find /Users/p.bykov/dir1 -name "log.log")"
do
for DATE in $(find /Users/p.bykov/dir1 -name "log.log" | cut -c21-25 | tr '/' '_')
do
NAME=$PATH
/bin/echo "$PATH"
done
    #NML=$(/usr/bin/find /Users/p.bykov/dir1 -name "log.log" | cut -c21-33 | tr '/' '_')
    #((i=i+1))
    
    #mkdir -p /Users/p.bykov/dir2/dircopy/$NAME
    #echo $lll
    #/bin/cp $lll /Users/p.bykov/dir2/dircopy/$NAME-log.log
done
#/bin/ls -la /Users/p.bykov/dir2/dircopy/

exit 0
