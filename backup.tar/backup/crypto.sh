#!/bin/sh

SEARCH_NUM=$(find /Users/p.bykov/dir1 -type f | wc -l)
SEARCH_FILE=$(find /Users/p.bykov/dir1 -type f)
MOVE_FILE=$(/bin/mv ${SEARCH_FILE} /Users/p.bykov/dir2)

if [ ${SEARCH_NUM} -ge 1 ]; then
echo "$SEARCH_NUM"
$MOVE_FILE
else
exit 1
fi
