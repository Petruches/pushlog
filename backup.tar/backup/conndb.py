import psycopg2

conn = psycopg2.connect(dbname="mysite", user="django", password="123456", host="127.0.0.1")
print(str(conn.status))
conn.close()
