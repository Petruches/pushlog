import redis

r = redis.Redis(
    host="s6516.qiwi.com",
    password=r"bjRkSCUVXsFGN0Mb",
    port=6379,
    db=0,

)

print(r.set("KEY", "VALUE"))
print(r.get("KEY"))
