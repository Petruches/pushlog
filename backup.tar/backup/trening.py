'''with open('network', 'a') as file:
    file.write("address 10.10.10.10\n")
    file.write("netmask 255.255.255.0\n")
    file.write("gateway 10.10.10.1\n")
'''
print("update /etc/network/interfaces")
address = input("ip: ")
gateway = input("gateway: ")
with open('network', 'r') as file:
    lines = file.readlines()

#lines.insert(1, "dns-search qiwi.com\n")
lines[8] = f"    address {address}\n"
lines[12] = f"    gateway {gateway}\n"

with open('network', 'w') as file:
    file.writelines(lines)
