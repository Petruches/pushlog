#!/bin/bash
i=1
while :
do
sl
#sleep 7
done
