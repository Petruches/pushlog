#!/bin/bash

file="testfile"
for server in $(cat $file)
do
echo $server
ssh -o StrictHostKeyChecking=no $server "sudo puppet agent --disable p.bykov"
done
