class test:
    def info():
        return "hello"

sss = "dsadas"

print(type(sss))
