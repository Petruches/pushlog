#!/usr/bin/env python

import ldap, sys
LDAP_SERVER = 'ldaps://hq.qiwi.com'
LDAP_BASE = 'OU=static-uz-sftp,DC=hq,DC=qiwi,DC=com'
BIND_USER = 'uid=p.bykov,OU=static-uz-sftp,DC=hq,DC=qiwi,DC=com'
BIND_PASSWORD = 'Kia19532805nisan'

ldap.set_option(ldap.OPT_DEBUG_LEVEL, 4095)

try:
    l = ldap.initialize(LDAP_SERVER)
except ldap.LDAPErrot as e:
    sys.stderr.write("Fatal Error\n")
    raise
