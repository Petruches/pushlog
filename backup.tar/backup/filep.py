print("dasdsads\n")
my_file = open("/Users/p.bykov/myscripts/python/test.txt", "a+")
read_file == my_file.read()
print(my_file.name)

#my_file = open("/Users/p.bykov/myscripts/python/test.txt", "w+")
#my_file.write("hellow world")
#my_file.close()
