
#!/bin/bash
s=0
i=0
for var in 2.2 3.1 5.5 1.6
do
#((s=$var+$s))
s=$(echo "$var + $s" | bc)
((i=1+$i))
done
echo $s
echo $i
r=$(echo "$s/$i" | bc)
echo "-----"
echo $r
