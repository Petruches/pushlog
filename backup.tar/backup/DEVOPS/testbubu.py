import requests
import json

req = requests.get("https://gerrit.osmp.ru/a/projects/", auth=('p.bykov', 'Ramilis#18120528#'))


arr_all = req

#a = json.loads(arr_all)

print(json.dumps(req.json()["1c-nsis"], indent=4))
