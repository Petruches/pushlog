#for VAR in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#do
#echo $VAR
#echo $VAR > cubectl sw
#cubectl cluster-info | head -1
#done

for ((i=1;i <= 10; i++))
do
#echo $i
echo $i | cubectl sw 1>/dev/null
cubectl cluster-info | head -1
cubectl get all --all-namespaces -l app=ao-qd-telegram-notifiyer
done
