#!/bin/bash

if [ -e ./.git ]; then
STR=$(cat ./.git/HEAD)
echo ${STR:16}
#ECH=$(echo ${STR:16})
else
echo "not"
fi
