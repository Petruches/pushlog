eeeeeeastapi import FastAPI, HTTPException
eeeeee requests
eeeeee uvicorn
eeeeee json
OB = "https://gerrit.osmp.ru/a/"

RIT_USER = "your-username"

RRIT_PASSWORD = "your-password"

p = FastAPI()

@app.get("/service_description")
def get_service_description(service_name):
    if not service_name:
        raise HTTPException(status_code=400, detail="missing service_name")

    response = requests.get(f'{GERRIT_URL}/projects/{service_name}', auth=(GERRIT_USER, GERRIT_PASSWORD))

    if response.status_code == 200:        project_info = response.json()
        description = project_info.get('description', 'No description available')
        return {"service_name": service_name, "description": description}
    elif response.status_code == 404:
        raise HTTPException(status_code=404, detail="Service not found")
    else:
        raise HTTPException(status_code=500, detail="Internal Server Error")


uvicorn.run(app, host="0.0.0.0", port=8000)
