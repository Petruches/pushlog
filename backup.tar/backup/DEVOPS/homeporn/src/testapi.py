import requests
import json

req = requests.get('https://jira.osmp.ru/rest/api/2/search?jql=project%3D%20DEVOPS', auth=('p.bykov', 'Ramilis#18120528#'))

#print(req.status_code)
#print(req.json()["issues"][0])
#print(json.dumps(req.json()["issues"][0]["fields"]["project"], indent=4))
arr_all = json.dumps(req.json()["issues"], indent=4)

arr_project = json.dumps(req.json()["issues"][0]["fields"]["project"], indent=4)
arr_issuetype = json.dumps(req.json()["issues"][0]["fields"]["issuetype"], indent=4)
arr_status = json.dumps(req.json()["issues"][0]["fields"]["status"], indent=4)

NUM_TIKETS: int = len(req.json()["issues"])
TOTAL = 4984
lst: list = []

for i in range(0, NUM_TIKETS-1):
    arr_project = json.dumps(req.json()["issues"][i]["fields"]["project"], indent=4)
    project: dict = json.loads(arr_project)
    lst.append(arr_project)

print(lst)
#print(len(req.json()["issues"]))
'''
print(json.loads(arr_project))
print()
print(json.loads(arr_issuetype))
print()
print(json.loads(arr_status))
'''
def test():
    return json.loads(arr)["id"]
