#from typing import Union
from fastapi import FastAPI
import requests
import json
import password

app = FastAPI()

URL_API = "https://jira.osmp.ru/rest/api/2/"
req = requests.get(f'{URL_API}search?jql=project%3D%20DEVOPS', auth=('p.bykov', ''))

#project = json.dumps(req.json()["issues"][0]["fields"]["project"], indent=4)
#issuetype = json.dumps(req.json()["issues"][0]["fields"]["issuetype"], indent=4)
#status = json.dumps(req.json()["issues"][0]["fields"]["status"], indent=4)

NUM_TIKETS: int = len(req.json()["issues"])

#arr_project: dict = json.loads(project)
#arr_issuetype: dict = json.loads(issuetype)
#arr_status: dict = json.loads(status)

goodjson: list = []
#goodjson.append(arr_project)
#goodjson.append(arr_issuetype)
#goodjson.append(arr_status)
test: dict = {"world":"hello"}

def read_project():
    try:
        for i in range(0, NUM_TIKETS-1):
            goodjson.append(json.loads(json.dumps(req.json()["issues"][i]["fields"]["project"], indent=4)))
            goodjson.append(json.loads(json.dumps(req.json()["issues"][i]["fields"]["issuetype"], indent=4)))
            goodjson.append(json.loads(json.dumps(req.json()["issues"][i]["fields"]["status"], indent=4)))
    except Exeption as e:
        print(e)

def read_num_project(item_id: int):
    try:
        goodjson.append(json.loads(json.dumps(req.json()["issues"][item_id]["fields"]["project"], indent=4)))
        goodjson.append(json.loads(json.dumps(req.json()["issues"][item_id]["fields"]["issuetype"], indent=4)))
        goodjson.append(json.loads(json.dumps(req.json()["issues"][item_id]["fields"]["status"], indent=4)))
    except Exeption as e:
        print(e)

def read_issuetype():
    try:
        for i in range(0, NUM_TIKETS-1):
            arr_issuetype = json.dumps(req.json()["issues"][i]["fields"]["issuetype"], indent=4)
            issuetype: dict = json.loads(arr_issuetype)
            goodjson.append(issuetype)
    except Exeption as e:
        print(e)
    
def read_status():
    try:
        for i in range(0, NUM_TIKETS-1):
            arr_status = json.dumps(req.json()["issues"][i]["fields"]["status"], indent=4)
            status: dict = json.loads(arr_status)
            goodjson.append(status)
    except Exeption as e:
        print(e)

class read():
    def __init__(self, project: str, issuetype: str, status: str):
        self.project = project
        self.issuetype = issuetype
        self.status = status

    def read_project():
        try:
            for i in range(0, NUM_TIKETS-1):
                goodjson.append(json.loads(json.dumps(req.json()["issues"][i]["fields"][self.project], indent=4)))
                goodjson.append(json.loads(json.dumps(req.json()["issues"][i]["fields"][self.issuetype], indent=4)))
                goodjson.append(json.loads(json.dumps(req.json()["issues"][i]["fields"][self.status], indent=4)))
        except Exeption as e:
            print(e)

    def read_num_project(item_id: int):
        try:
            goodjson.append(json.loads(json.dumps(req.json()["issues"][item_id]["fields"][self.project], indent=4)))
            goodjson.append(json.loads(json.dumps(req.json()["issues"][item_id]["fields"][self.issuetype], indent=4)))
            goodjson.append(json.loads(json.dumps(req.json()["issues"][item_id]["fields"][self.status], indent=4)))
        except Exeption as e:
            print(e)

class main():
    @app.get("/")
    def read_root():
        return test

    @app.get("/jr/{item_id}")
    def read_jr_item(item_id: int):
        if (goodjson != []):
            goodjson.clear()
            read_num_project(item_id)
            return goodjson
        else:
            read_num_project(item_id)
            return goodjson

    @app.get("/jira")
    def read_jira():
        if (goodjson != []):
            goodjson.clear()
            read_project()
            return goodjson
        else:
            read_project()
            return goodjson

    @app.get("/jiratest")
    def read_jira():
        rd = read("project", "issuetype", "status")
        if (goodjson != []):
            goodjson.clear()
            rd.read_project()
            return goodjson
        else:
            rd.read_project()
            return goodjson

    @app.get("/jrtest/{item_id}")
    def read_jr_item(item_id: int):
        rd = read("project", "issuetype", "status")
        if (goodjson != []):
            goodjson.clear()
            rd.read_num_project(item_id)
            return goodjson
        else:
            rd.read_num_project(item_id)
            return goodjson
