class read:
    pass