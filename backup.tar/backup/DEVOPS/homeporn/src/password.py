class password:
    def passwd():
        return 'Ramilis#18120528#'