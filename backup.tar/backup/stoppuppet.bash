#!/bin/bash

#ssh -o StrictHostKeyChecking=no p.bykov@s6043.qiwi.com "puppet agent --version"
FILE="testfile"

for FL in $(cat $FILE)
do
echo $FL
ssh -o StrictHostKeyChecking=no p.bykov@$FL "python3.12 -m pip list"
done
